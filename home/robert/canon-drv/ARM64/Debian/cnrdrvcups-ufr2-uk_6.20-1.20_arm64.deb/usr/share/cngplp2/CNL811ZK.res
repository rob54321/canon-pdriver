<?xml version="1.0"?>
<KeyTextList>
<Item key="CNMatchingMethod_Photographic">General </Item>
<Item key="CNMatchingMethod_Monitor">Perceptual </Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
<Item key="MediaType_2SIDECOATED1">Coated 1</Item>
<Item key="MediaType_2SIDECOATED2">Coated 2</Item>
<Item key="MediaType_2SIDECOATED3">Coated 3</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_Off">Off</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
<Item key="PageSize_11x17">11x17 </Item>
<Item key="PageSize_Ledger">Ledger</Item>
</KeyTextList>
