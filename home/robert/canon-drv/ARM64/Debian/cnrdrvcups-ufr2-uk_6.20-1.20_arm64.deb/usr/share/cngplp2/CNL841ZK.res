<?xml version="1.0"?>
<KeyTextList>
<Item key="CNTonerSaving">Toner Save: </Item>
<Item key="MediaType_1SIDECOATED1">Coated Paper 1</Item>
<Item key="MediaType_1SIDECOATED2">Coated Paper 2</Item>
<Item key="MediaType_1SIDECOATED3">Coated Paper 3</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNFeedAFiveVertically">Feed A4/A5/Letter Vertically:</Item>
<Item key="CNPlainPaperCurlCorrect">Special Print Mode (Plain Paper):</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_None">Printer Default</Item>
<Item key="CNBarCodeMode_Off">Normal</Item>
<Item key="CNBarCodeMode_Mode1">Narrow</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
</KeyTextList>
