<?xml version="1.0"?>
<KeyTextList>
<Item key="CNProPuncher">Professional Puncher</Item>
<Item key="CNProPuncher_False">OFF</Item>
<Item key="CNProPuncher_True">ON</Item>
<Item key="CNEnableTrustPrint">Secure Watermark Function of Device</Item>
<Item key="CNTrustPrint">Use Secure Watermark Function of Device</Item>
<Item key="CNSrcOption_OptCas1">Paper Deck Unit-E1</Item>
<Item key="CNSrcOption_OptCas2">POD Deck Lite-C1</Item>
<Item key="CNSrcOption_OptCas3">Multi-drawer Paper Deck-E1</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNFrontPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNBackPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="MediaType_TRACING">Tracing</Item>
<Item key="CNPerforation_Location1">1 Location (Fixed at Center)</Item>
<Item key="CNCrease_Location2">2 Locations (Positions for 3 Equal Sections)</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
<Item key="PageSize_11x17">11x17 </Item>
<Item key="PageSize_Ledger">Ledger</Item>
<Item key="MediaType_BOND">Bond</Item>
<Item key="CNInterleafMediaType_BOND">Bond</Item>
<Item key="MediaType_1SIDECOATEDF1">1-sided Coated Thin</Item>
<Item key="MediaType_2SIDECOATEDF1">2-sided Coated Thin</Item>
<Item key="MediaType_MATTECOATEDF1">Matte Coated Thin</Item>
<Item key="CNInterleafMediaType_1SIDECOATEDF1">1-sided Coated Thin</Item>
<Item key="CNInterleafMediaType_2SIDECOATEDF1">2-sided Coated Thin</Item>
<Item key="CNInterleafMediaType_MATTECOATEDF1">Matte Coated Thin</Item>
</KeyTextList>

