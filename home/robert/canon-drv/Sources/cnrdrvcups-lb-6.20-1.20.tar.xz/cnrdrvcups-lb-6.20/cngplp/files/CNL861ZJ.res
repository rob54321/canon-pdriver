<?xml version="1.0"?>
<KeyTextList>
<Item key="CNMatchingMethod_Photographic">General </Item>
<Item key="CNMatchingMethod_Monitor">Perceptual </Item>
<Item key="CNTonerSaving">Toner Save: </Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
<Item key="MediaType_2SIDECOATED1">Coated 1</Item>
<Item key="MediaType_2SIDECOATED2">Coated 2</Item>
<Item key="MediaType_2SIDECOATED3">Coated 3</Item>
<Item key="MediaType_HEAVY4">Heavy Paper 4</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNFeedAFiveVertically">Feed A4/A5/Letter Vertically:</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_Off">Off</Item>
</KeyTextList>
