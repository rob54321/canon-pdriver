<?xml version="1.0"?>
<KeyTextList>
<Item key="CNDraftMode">Toner Save:</Item>
<Item key="MediaType_PlainPaperL2">Plain Paper L2</Item>
<Item key="CNInterleafMediaType_PlainPaperL2">Plain Paper L2</Item>
<Item key="CNFeedAFiveVertically">Feed A4/Letter Vertically:</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_None">Printer Default</Item>
<Item key="CNBarCodeMode_Off">Off</Item>
<Item key="CNBarCodeMode_Mode1">Mode 1</Item>
<Item key="CNBarCodeMode_Mode2">Mode 2</Item>
<Item key="CNBarCodeMode_Mode3">Mode 3</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
</KeyTextList>
