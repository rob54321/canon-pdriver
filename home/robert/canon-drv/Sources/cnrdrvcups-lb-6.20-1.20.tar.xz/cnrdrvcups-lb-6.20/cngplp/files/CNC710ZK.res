<?xml version="1.0"?>
<KeyTextList>
<Item key="CNSrcOption_OptCas1">POD Deck Lite-C1</Item>
<Item key="CNSrcOption_OptCas2">POD Deck Lite XL-A1</Item>
<Item key="CNSrcOption_OptCas3">Multi-drawer Paper Deck-C1</Item>
<Item key="CNSrcOption_OptCas4">Multi-drawer Paper Deck-D1</Item>
<Item key="CNSrcOption_OptCas5">Multi-drawer Paper Deck-D1 + POD Deck Lite XL-A1</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNFrontPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNBackPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
</KeyTextList>
