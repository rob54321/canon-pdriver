<?xml version="1.0"?>
<KeyTextList>
<Item key="MediaType_PlainPaper1">Plain Paper 1</Item>
<Item key="MediaType_PlainPaper2">Plain Paper 2</Item>
<Item key="MediaType_RECYCLED1">Recycled Paper 1</Item>
<Item key="MediaType_RECYCLED2">Recycled Paper 2</Item>
<Item key="MediaType_RECYCLED3">Recycled Paper 3</Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
</KeyTextList>
