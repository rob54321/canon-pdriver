<?xml version="1.0"?>
<KeyTextList>
<Item key="CNDraftMode">Toner Save:</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_Off">Off</Item>
<Item key="CNBarCodeMode_Mode1">Mode 1</Item>
<Item key="CNBarCodeMode_Mode2">Mode 2</Item>
<Item key="CNBarCodeMode_Mode3">Mode 3</Item>
</KeyTextList>
