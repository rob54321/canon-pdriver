<?xml version="1.0"?>
<KeyTextList>
<Item key="MediaType_TRACING">Tracing</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="InputSlot_SideDeck">Drawer 5 </Item>
<Item key="CNFrontPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNFrontPaperSrc_SideDeck">Drawer 5 </Item>
<Item key="CNBackPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNBackPaperSrc_SideDeck">Drawer 5 </Item>
</KeyTextList>