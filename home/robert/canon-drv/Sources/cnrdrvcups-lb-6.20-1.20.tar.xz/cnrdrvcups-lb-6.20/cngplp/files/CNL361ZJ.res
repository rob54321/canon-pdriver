<?xml version="1.0"?>
<KeyTextList>
<Item key="CNDraftMode">Draft Mode:</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNFeedAFiveVertically">Feed A5 Vertically:</Item>
<Item key="CNSpecialPrintMode">Blurry Image Correction:</Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
<Item key="MediaType_BOND">Bond</Item>
<Item key="MediaType_PREPUNCHED">Pre-Punched</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_Off">Off</Item>
<Item key="CNBarCodeMode_Mode1">Mode 1</Item>
<Item key="CNBarCodeMode_Mode2">Mode 2</Item>
<Item key="CNBarCodeMode_Mode3">Mode 3</Item>
<Item key="CNBarCodeMode_Mode4">Mode 4</Item>
<Item key="CNBarCodeMode_Mode5">Mode 5</Item>
</KeyTextList>
