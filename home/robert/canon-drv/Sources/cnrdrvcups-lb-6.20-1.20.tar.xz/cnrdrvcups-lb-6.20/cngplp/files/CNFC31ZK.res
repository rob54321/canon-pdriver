<?xml version="1.0"?>
<KeyTextList>
<Item key="CNMatchingMethod_Photographic">General </Item>
<Item key="CNMatchingMethod_Monitor">Perceptual </Item>
<Item key="MediaType_PlainPaper1">Plain Paper 1</Item>
<Item key="MediaType_PlainPaper2">Plain Paper 2</Item>
<Item key="MediaType_RECYCLED1">Recycled Paper 1</Item>
<Item key="MediaType_RECYCLED2">Recycled Paper 2</Item>
<Item key="MediaType_RECYCLED3">Recycled Paper 3</Item>
<Item key="MediaType_HEAVY4">Heavy Paper 4</Item>
<Item key="MediaType_HEAVY5">Heavy Paper 5</Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNTrustPrint">Use Secure Watermark Function of Device</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_Mode1">Mode 1</Item>
<Item key="CNBarCodeMode_Mode2">Mode 2</Item>
<Item key="CNBarCodeMode_Mode3">Mode 3</Item>
<Item key="CNBarCodeMode_Mode4">Mode 4</Item>
<Item key="CNBarCodeMode_Mode5">Mode 5</Item>
<Item key="CNBarCodeMode_Off">Off</Item>
<Item key="CNEnableTrustPrint">Secure Watermark Function of Device</Item>
<Item key="OutputBin_TrayLowerInternal">Tray (Finisher, Internal)</Item>
<Item key="OutputBin_TrayUpperInternal">Tray (Finisher, Upper Internal)</Item>
</KeyTextList>
