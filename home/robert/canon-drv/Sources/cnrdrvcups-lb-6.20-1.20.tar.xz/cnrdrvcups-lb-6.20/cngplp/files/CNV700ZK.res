<?xml version="1.0"?>
<KeyTextList>
<Item key="CNEnableTrustPrint">Secure Watermark Function of Device</Item>
<Item key="CNTrustPrint">Use Secure Watermark Function of Device</Item>
<Item key="CNMatchingMethod_Photographic">General </Item>
<Item key="CNMatchingMethod_Monitor">Perceptual </Item>
<Item key="CNSrcOption_OptCas1">POD Deck Lite-C1</Item>
<Item key="CNSrcOption_OptCas2">POD Deck Lite XL-A2</Item>
<Item key="CNSrcOption_OptCas3">Multi-drawer Paper Deck-E1</Item>
<Item key="CNSrcOption_OptCas4">POD Deck-F1</Item>
<Item key="CNSrcOption_OptCas5">Multi-drawer Paper Deck-E1 + POD Deck Lite XL-A2</Item>
<Item key="CNSrcOption_OptCas6">POD Deck-F1 + POD Deck Lite XL-A2</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNFrontPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNBackPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
<Item key="CNInterleafMediaType_PlainPaperL">Thin</Item>
<Item key="CNPerforation_Location1">1 Location (Fixed at Center)</Item>
<Item key="CNCrease_Location2">2 Locations (Positions for 3 Equal Sections)</Item>
</KeyTextList>
