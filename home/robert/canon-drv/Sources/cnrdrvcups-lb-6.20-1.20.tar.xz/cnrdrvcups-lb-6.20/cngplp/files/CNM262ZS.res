<?xml version="1.0"?>
<KeyTextList>
<Item key="CNSpecialPrintAdjustmentA">Blurry Image Correction:</Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
</KeyTextList>
