<?xml version="1.0"?>
<KeyTextList>
<Item key="CNEnableTrustPrint">Secure Printing Function of Device</Item>
<Item key="MediaType_PlainPaper1">Plain Paper 1</Item>
<Item key="MediaType_PlainPaper2">Plain Paper 2</Item>
<Item key="MediaType_HEAVY4">Heavy Paper 4</Item>
<Item key="MediaType_HEAVY5">Heavy Paper 5</Item>
<Item key="MediaType_TRACING">Tracing</Item>
<Item key="MediaType_THIN1">Thin 1</Item>
<Item key="MediaType_THIN2">Thin 2</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="InputSlot_SideDeck">Drawer 5 </Item>
<Item key="CNInterleafMediaType_PlainPaper1">Plain Paper 1</Item>
<Item key="CNInterleafMediaType_PlainPaper2">Plain Paper 2</Item>
<Item key="CNInterleafMediaType_BOND">Bond Paper</Item>
<Item key="CNInterleafMediaType_THIN1">Thin 1</Item>
<Item key="CNInterleafMediaType_THIN2">Thin 2</Item>
<Item key="CNFrontPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNFrontPaperSrc_SideDeck">Drawer 5 </Item>
<Item key="CNBackPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNBackPaperSrc_SideDeck">Drawer 5 </Item>
<Item key="CNTrustPrint">Use Secure Printing Function of Device</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
</KeyTextList>
