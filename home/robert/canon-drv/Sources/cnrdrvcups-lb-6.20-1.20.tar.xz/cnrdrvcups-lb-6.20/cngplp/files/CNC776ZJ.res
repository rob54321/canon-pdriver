<?xml version="1.0"?>
<KeyTextList>
<Item key="CNSrcOption_OptCas3">Paper Deck Unit-E1</Item>
<Item key="CNSrcOption_OptCas2">POD Deck Lite-C1</Item>
<Item key="CNSrcOption_OptCas1">Multi-drawer Paper Deck-C1</Item>
<Item key="CNMatchingMethod_Photographic">General </Item>
<Item key="CNMatchingMethod_Monitor">Perceptual </Item>
<Item key="MediaType_TRACING">Tracing</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="InputSlot_SideDeck">Drawer 5 </Item>
<Item key="InputSlot_PodDeck">Drawer 5  </Item>
<Item key="CNFrontPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNFrontPaperSrc_Cas5">Drawer 5</Item>
<Item key="CNFrontPaperSrc_SideDeck">Drawer 5 </Item>
<Item key="CNFrontPaperSrc_PodDeck">Drawer 5  </Item>
<Item key="CNFrontPaperSrc_Cas6">Drawer 6</Item>
<Item key="CNFrontPaperSrc_Cas7">Drawer 7</Item>
<Item key="CNBackPaperSrc_Manual">Multi-purpose Tray</Item>
<Item key="CNBackPaperSrc_Cas5">Drawer 5</Item>
<Item key="CNBackPaperSrc_SideDeck">Drawer 5 </Item>
<Item key="CNBackPaperSrc_PodDeck">Drawer 5  </Item>
<Item key="CNBackPaperSrc_Cas6">Drawer 6</Item>
<Item key="CNBackPaperSrc_Cas7">Drawer 7</Item>
</KeyTextList>