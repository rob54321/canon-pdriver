<?xml version="1.0"?>
<KeyTextList>
<Item key="CNDraftMode">Toner Save:</Item>
<Item key="MediaType_PlainPaperL2">Plain Paper L2</Item>
<Item key="MediaType_HEAVY4">Heavy Paper 4</Item>
<Item key="CNSpecialPrintMode">Special Print Adjustment:</Item>
</KeyTextList>