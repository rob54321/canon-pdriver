<?xml version="1.0"?>
<KeyTextList>
<Item key="CNMatchingMethod_Photographic">General </Item>
<Item key="CNMatchingMethod_Monitor">Perceptual </Item>
<Item key="CNTonerSaving">Toner Save: </Item>
<Item key="MediaType_1SIDECOATED1">Coated Paper 1</Item>
<Item key="MediaType_1SIDECOATED2">Coated Paper 2</Item>
<Item key="MediaType_1SIDECOATED3">Coated Paper 3</Item>
<Item key="MediaType_PlainPaperL2">Plain Paper L2</Item>
<Item key="MediaType_HEAVY4">Heavy Paper 4</Item>
<Item key="MediaType_HEAVY5">Heavy Paper 5</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNFeedAFiveVertically">Feed A4/A5/Letter Vertically:</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_Off">Off</Item>
</KeyTextList>
