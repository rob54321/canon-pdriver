<?xml version="1.0"?>
<KeyTextList>
<Item key="CNTonerSaving">Toner Save: </Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNSpecialPrintMode">Blurry Image Correction:</Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
</KeyTextList>
