<?xml version="1.0"?>
<KeyTextList>
<Item key="CNMatchingMethod_Photographic">General </Item>
<Item key="CNMatchingMethod_Monitor">Perceptual </Item>
<Item key="MediaType_PlainPaperL">Thin</Item>
<Item key="MediaType_PlainPaper1">Plain Paper 1</Item>
<Item key="MediaType_PlainPaper2">Plain Paper 2</Item>
<Item key="MediaType_RECYCLED1">Recycled Paper 1</Item>
<Item key="MediaType_RECYCLED2">Recycled Paper 2</Item>
<Item key="MediaType_1SIDECOATED1">Coated 1</Item>
<Item key="MediaType_1SIDECOATED2">Coated 2</Item>
<Item key="MediaType_1SIDECOATED3">Coated 3</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_Off">Off</Item>
<Item key="CNBarCodeMode_Mode1">Mode 1</Item>
<Item key="CNBarCodeMode_Mode2">Mode 2</Item>
<Item key="CNBarCodeMode_Mode3">Mode 3</Item>
<Item key="CNBarCodeMode_Mode4">Mode 4</Item>
<Item key="CNBarCodeMode_Mode5">Mode 5</Item>
</KeyTextList>
