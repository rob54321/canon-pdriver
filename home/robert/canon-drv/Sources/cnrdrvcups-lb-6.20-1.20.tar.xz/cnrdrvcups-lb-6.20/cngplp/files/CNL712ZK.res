<?xml version="1.0"?>
<KeyTextList>
<Item key="CNMatchingMethod_Photographic">General </Item>
<Item key="CNMatchingMethod_Monitor">Perceptual </Item>
<Item key="CNTonerSaving">Toner Save: </Item>
<Item key="MediaType_PlainPaperL2">Plain Paper L2</Item>
<Item key="MediaType_HEAVY4">Heavy Paper 4</Item>
<Item key="InputSlot_Manual">Multi-purpose Tray</Item>
<Item key="CNFeedAFiveVertically">Feed A5 Vertically:</Item>
<Item key="CNBarCodeMode">Barcode Adjustment Mode:</Item>
<Item key="CNBarCodeMode_None">Printer Default</Item>
<Item key="CNBarCodeMode_Off">Normal</Item>
<Item key="CNBarCodeMode_Mode1">Narrow</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
</KeyTextList>
