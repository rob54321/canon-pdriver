/*
 *  JBIG image compression library for Canon LIPSLX/UFR2/NCAP Printer.
 *  Copyright CANON INC. 2018
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef cnjbig_h
#define cnjbig_h

#pragma pack(1)

typedef struct _CNJBIGDATAHEADER {
	int x;
	int y;
	unsigned long l0;
} CNJBIGDATAHEADER, *LPCNJBIGDATAHEADER;

#pragma pack()

#endif
