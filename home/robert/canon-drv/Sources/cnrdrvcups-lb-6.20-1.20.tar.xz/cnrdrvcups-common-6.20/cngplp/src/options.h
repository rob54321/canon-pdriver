/*
 *  Print Dialog for Canon LIPS/PS/LIPSLX/UFR2/CAPT Printer.
 *  Copyright CANON INC. 2017
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _OPTIONS
#define _OPTIONS


typedef enum {
	kOPTION_USE_CIE_COLOR_OFF,
	kOPTION_USE_CIE_COLOR_ON
} OPTION_USE_CIE_COLOR;

typedef enum {
	kOPTION_CORRECT_GRAY_OFF,
	kOPTION_CORRECT_GRAY_ON
} OPTION_CORRECT_GRAY;


typedef struct{
	OPTION_USE_CIE_COLOR use_cie_color;
	OPTION_CORRECT_GRAY correct_gray;
}CNGPLP_OPTIONS;

#define kCNGPLP_OPTIONS_INITIALIZER	\
{\
	kOPTION_USE_CIE_COLOR_OFF,\
	kOPTION_CORRECT_GRAY_OFF,\
}

void SaveCngplpOption(const CNGPLP_OPTIONS *options);
CNGPLP_OPTIONS* LoadCngplpOption();

#endif
