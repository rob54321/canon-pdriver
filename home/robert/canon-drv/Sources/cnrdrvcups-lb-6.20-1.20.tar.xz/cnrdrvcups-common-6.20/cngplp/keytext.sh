#
# Modified by Canon INC. on Jul. 2010
# [Change Log]
# the path and name of input file changed.
#
#!/bin/bash
/usr/bin/intltool-extract --type=gettext/glade src/cngplp.ui> /dev/null

cat >gladestr.h <<EOF
EOF
cat src/cngplp.ui.h >>gladestr.h
rm src/cngplp.ui.h
